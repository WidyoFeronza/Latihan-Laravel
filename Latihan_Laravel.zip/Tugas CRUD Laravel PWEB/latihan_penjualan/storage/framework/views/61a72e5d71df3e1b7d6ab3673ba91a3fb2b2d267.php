
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
            <div class="card">
                <div class="panel panel-default">
                    <div class="panel-head container-fluid" style="margin-top: 10px;">
                        <div class="col-md-5" style="font-size: 2rem;">
                            <p>Perbaharui Data Produk</p>
                        </div>
                    </div>
                    <div class="card-body">
                        <form class="form-horizontal" action="<?php echo e(route('produk.update',$produk->id)); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="_method" value="PUT">
                                <div class="form-group">
                                    <label class="control-label col-sm-2">Nama Produk</label>
                                        <div class="col-sm-12">
                                            <input type="text" class="form-control" name="nama" value="<?php echo e($produk->nama); ?>">
                                        </div>
                                </div>
                                <br>

                                <div class="form-group">
                                    <label class="control-label col-sm-2">Kategori Produk</label>
                                        <div class="col-sm-12">
                                            <select class="form-control" name="kategori">
                                                <option value="">Pilih Kateogri</option>
                                                    <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($k->id); ?>" <?php if($produk->id_kategori==$k->id): ?> selected <?php endif; ?>><?php echo e($k->nama); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                </div>
                                <br>

                                <div class="form-group">
                                    <label class="control-label col-sm-2">Qty Awal</label>
                                        <div class="col-sm-12">
                                            <input type="text" class="form-control" name="qty" value="<?php echo e($produk->qty); ?>">
                                        </div>
                                </div>
                                <br>

                                <div class="form-group">
                                    <label class="control-label col-sm-2">Harga Beli</label>
                                        <div class="col-sm-12">
                                            <input type="text" class="form-control" name="beli" value="<?php echo e($produk->harga_beli); ?>">
                                        </div>
                                </div>
                                <br>

                                <div class="form-group">
                                    <label class="control-label col-sm-2">Harga Jual</label>
                                        <div class="col-sm-12">
                                            <input type="text" class="form-control" name="jual" value="<?php echo e($produk->harga_jual); ?>">
                                        </div>
                                </div>
                                <br>

                                <div class="form-group">
                                    <div class="col-sm-offset-2 col-sm-10">
                                        <button type="submit" class="btn btn-primary">Perbaharui Data</button>
                                    </div>
                                </div>
                        </form>
                    </div>
                </div>
            </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Tugas CRUD Laravel PWEB\latihan_penjualan\resources\views/produk/edit.blade.php ENDPATH**/ ?>