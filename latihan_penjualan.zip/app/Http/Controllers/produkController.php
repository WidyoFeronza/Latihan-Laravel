<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\produk;
class produkController extends Controller
{
    //
    public function index()
    {
        $produk = produk::all();
        return view('produk.index');
    }
    //
    public function store(Request $request)
    {
        produk::create([
        'nama' => $request->nama,
        'id_kategori' => $request->kategori,
        'qty' => $request->qty,
        'harga_beli' => $request->beli,
        'harga_jual' => $request->jual,
        ]);
        return redirect()->route('produk.index');
    }
}
